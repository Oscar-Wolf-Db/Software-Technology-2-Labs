import time
import random
import string
import tkinter as tk
from tkinter import ttk

# ===== BST Node and BST Class =====

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            # Node with one or no children
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
            # Node with two children
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

# ===== AVL Node and AVL Tree Class =====

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1

class RedBlackNode:
    """Represents a node in a Red-Black Tree."""
    def __init__(self, key, color="RED"):
        self.key = key
        self.color = color  # RED or BLACK
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    """Implements a Red-Black Tree with balancing after insertions and deletions."""
    
    def __init__(self):
        self.NIL = RedBlackNode(None, "BLACK")  # Sentinel NIL node
        self.root = self.NIL  # Root of the tree

    def insert(self, key):
        """Inserts a new key into the Red-Black Tree and balances it."""
        new_node = RedBlackNode(key)
        new_node.left = self.NIL
        new_node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if new_node.key < current.key:
                current = current.left
            else:
                current = current.right

        new_node.parent = parent

        if parent is None:  # Tree was empty
            self.root = new_node
        elif new_node.key < parent.key:
            parent.left = new_node
        else:
            parent.right = new_node

        new_node.color = "RED"  # New nodes are always inserted as RED
        self._fix_insert(new_node)  # Balance the tree

    def _fix_insert(self, node):
        """Fixes the Red-Black Tree after an insertion to maintain balance."""
        while node.parent and node.parent.color == "RED":
            grandparent = node.parent.parent

            if node.parent == grandparent.left:  # Parent is a left child
                uncle = grandparent.right

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.right:  # Case 2: Left-Right → Rotate Left
                        node = node.parent
                        self._rotate_left(node)

                    # Case 3: Left-Left → Rotate Right
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_right(grandparent)

            else:  # Parent is a right child (Mirror cases)
                uncle = grandparent.left

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.left:  # Case 2: Right-Left → Rotate Right
                        node = node.parent
                        self._rotate_right(node)

                    # Case 3: Right-Right → Rotate Left
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_left(grandparent)

        self.root.color = "BLACK"  # Ensure root is always BLACK

    def search(self, key):
        """Searches for a key in the Red-Black Tree."""
        current = self.root
        while current != self.NIL:
            if key == current.key:
                return current  # Node found
            elif key < current.key:
                current = current.left
            else:
                current = current.right
        return None  # Not found

    def _rotate_left(self, node):
        """Performs a left rotation on the given node."""
        right_child = node.right
        node.right = right_child.left

        if right_child.left != self.NIL:
            right_child.left.parent = node

        right_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = right_child
        elif node == node.parent.left:
            node.parent.left = right_child
        else:
            node.parent.right = right_child

        right_child.left = node
        node.parent = right_child

    def _rotate_right(self, node):
        """Performs a right rotation on the given node."""
        left_child = node.left
        node.left = left_child.right

        if left_child.right != self.NIL:
            left_child.right.parent = node

        left_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = left_child
        elif node == node.parent.right:
            node.parent.right = left_child
        else:
            node.parent.left = left_child

        left_child.right = node
        node.parent = left_child

    def inorder_traversal(self, node):
        """Performs an inorder traversal of the tree."""
        if node != self.NIL:
            self.inorder_traversal(node.left)
            print(f"{node.key} ({node.color})", end=" ")
            self.inorder_traversal(node.right)

    def print_tree(self):
        """Prints the tree structure in a readable format."""
        def print_helper(node, indent, last):
            if node != self.NIL:
                print(indent, "`- " if last else "|- ", f"{node.key} ({node.color})", sep="")
                indent += "   " if last else "|  "
                print_helper(node.left, indent, False)
                print_helper(node.right, indent, True)

        print_helper(self.root, "", True)

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        # Rotations
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        # Balancing
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

# ===== Benchmarking Function =====

def benchmark(n=100000, search_fraction=0.5, delete_count=100, verbose=True):
    # Generate test data
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

    # --- BST benchmark ---
    bst = BST()
    bst.root = None

    # Insert
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.time() - start

    # Search
    search_names = random.sample(names, int(n*search_fraction)) + ['notfoundname'] * int(n*(1 - search_fraction))
    start = time.time()
    found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
    bst_search_time = time.time() - start

    # Delete
    delete_names = random.sample(names, delete_count)
    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.time() - start

    # --- AVL benchmark ---
    avl = AVLTree()
    avl.root = None

    # Insert
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.time() - start

    # Search
    start = time.time()
    found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
    avl_search_time = time.time() - start

    # Delete
    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.time() - start

        # --- R&B benchmark ---
    rab = RedBlackTree()

    # Insert
    start = time.time()
    for i in range(n):
        rab.insert(names[i])  
    rab_insert_time = time.time() - start

    # Search
    start = time.time()
    found_rab = sum(1 for name in search_names if rab.search(name)) 
    rab_search_time = time.time() - start
    
    # Prepare results
    results = {
        'Insertions': (bst_insert_time, avl_insert_time, rab_insert_time),
        'Searches': (bst_search_time, avl_search_time, rab_search_time),
        'Deletions': (bst_delete_time, avl_delete_time, 0),
        'Found In Search': (found_bst, found_avl, found_rab)
    }

    if verbose:
        print(f"Benchmarking with {n} entries:\n")
        print("Operation      BST Time (sec)    AVL Time (sec)    R&B Time (sec)")
        print("---------------------------------------------")
        print(f"Insertions:    {bst_insert_time:.6f}            {avl_insert_time:.6f}            {rab_insert_time:.6f}")
        print(f"Searches:      {bst_search_time:.6f}            {avl_search_time:.6f}            {rab_search_time:.6f}")
        print(f"Deletions:     {bst_delete_time:.6f}            {avl_delete_time:.6f}")
        print("---------------------------------------------")
        print(f"Contacts found in search:")
        print(f"BST: {found_bst} / {len(search_names)}")
        print(f"AVL: {found_avl} / {len(search_names)}")
        print(f"R&B: {found_rab} / {len(search_names)}")
    return results

# ===== Tkinter GUI to show benchmark results =====

class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL vs R&B Benchmark")

        self.label = tk.Label(master, text="Run benchmark with 100000 entries?")
        self.label.pack(pady=5)

        self.run_btn = tk.Button(master, text="Run Benchmark", command=self.run_benchmark)
        self.run_btn.pack(pady=5)

        self.result_text = tk.Text(master, height=15, width=50)
        self.result_text.pack(pady=10)

        self.tree = ttk.Treeview(master, columns=("BST", "AVL", "R&B"), show='headings')
        self.tree.heading("BST", text="BST Time (s)")
        self.tree.heading("AVL", text="AVL Time (s)")
        self.tree.heading("R&B", text="R&B Time (s)")
        self.tree.pack(pady=10)

    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)
        results = benchmark(verbose=False)  # silent print

        # Display text summary
        summary = (
            f"Insertion Time: BST: {results['Insertions'][0]:.6f}s, AVL: {results['Insertions'][1]:.6f}s, R&B: {results['Insertions'][2]:.6f}s\n"
            f"Search Time:    BST: {results['Searches'][0]:.6f}s, AVL: {results['Searches'][1]:.6f}s, R&B: {results['Searches'][2]:.6f}s\n"
            f"Deletion Time:  BST: {results['Deletions'][0]:.6f}s, AVL: {results['Deletions'][1]:.6f}s, R&B: {results['Deletions'][2]:.6f}s\n"
            f"Found in Search: BST: {results['Found In Search'][0]}, AVL: {results['Found In Search'][1]}, R&B: {results['Found In Search'][2]} out of 100000\n"
        )
        self.result_text.insert(tk.END, summary)

        # Clear previous treeview
        for row in self.tree.get_children():
            self.tree.delete(row)

        # Insert new data rows
        for op in ['Insertions', 'Searches', 'Deletions']:
            bst_time, avl_time, rab_time = results[op]
            self.tree.insert('', tk.END, values=(f"{bst_time:.6f}", f"{avl_time:.6f}", f"{rab_time:.6f}"), text=op)
        
# ===== Run the app =====

if __name__ == "__main__":
    root = tk.Tk()
    app = BenchmarkApp(root)
    root.mainloop()
import time
import random
import string
import matplotlib.pyplot as plt

# Re-use BST and AVL classes from previous code 
# Use BST and AVLTree classes already defined with 
# insert/search/delete methods.

def run_benchmark_for_sizes(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rab_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        # --- BST ---
        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        # --- AVL ---
        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

                # --- R&B ---
        rab = RedBlackTree()

        start = time.time()
        for i in range(n):
            rab.insert(names[i])
        rab_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            rab.search(name)
        rab_times['search'].append(time.time() - start)

    # Plot results
    plt.figure(figsize=(12, 8))

    # Insertions plot
    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times['insert'], label='BST Insert')
    plt.plot(sizes, avl_times['insert'], label='AVL Insert')
    plt.plot(sizes, rab_times['insert'], label='R&B Insert')
    plt.ylabel('Time (seconds)')
    plt.title('Insertion Time vs Input Size')
    plt.legend()

    # Searches plot
    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times['search'], label='BST Search')
    plt.plot(sizes, avl_times['search'], label='AVL Search')
    plt.plot(sizes, rab_times['search'], label='R&B Search')
    plt.ylabel('Time (seconds)')
    plt.title('Search Time vs Input Size')
    plt.legend()

    # Deletions plot
    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times['delete'], label='BST Delete')
    plt.plot(sizes, avl_times['delete'], label='AVL Delete')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Time (seconds)')
    plt.title('Deletion Time vs Input Size')
    plt.legend()

    plt.tight_layout()
    plt.show()

# Example usage:
if __name__ == "__main__":
    sizes_to_test = [100, 200, 400, 800, 1600]
    run_benchmark_for_sizes(sizes_to_test)
