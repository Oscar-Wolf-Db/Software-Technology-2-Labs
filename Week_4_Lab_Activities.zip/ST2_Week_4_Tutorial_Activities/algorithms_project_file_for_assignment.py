import timeit
import random

# Now that we've gotten some background on searching algorithms, let's
# try and implement some basic ones. First, we'll try the most basic of all:
# linear search. Despite its simplicity, linear search is actually the
# algorithm that Python lists use when we check membership with the 'in'
# keyword.
#
# Note that with the Python data structures we're using here, the function
# of these algorithms is not necessary (as the Python structures already
# implement searching, sorting, etc.). We are doing it for the sake of 
# learning the theory. In practice, it is recommended to use the
# built in searching functions!


# LINEAR SEARCH
# To review, linear search involves sequentially checking every element
# in a collection until the desired value is found.
def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i
        
    return -1

test = range(1000000)
print(linear_search(test, 99999))
print(linear_search(test, -999))


# BINARY SEARCH
# An alternative to linear search is binary search. Binary search can be more efficient than
# linear search, but with a few caveats.
# First, the algorithm is more complex (this tradeoff always exists), and second,
# it requires data to be sorted. If binary search is run on unsorted data, it
# can perform just as poorly as linear search and it may produce erroneous results.

def binary_search(array, target):

    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1

test = [1, 1, 1, 2, 3, 6, 9, 19, 555]
print(binary_search(test, 1))
print(binary_search(test, 555))

# Note another quirk of binary search is that it does not guarantee to return
# the first occurance of an element, just *some* occurance if that element does in fact appear.

# Comparing linear and binary search efficiency
# Generate a sorted list of integers for testing
sorted_list = list(range(1000000))

# Test cases
target = random.randint(0, 999999)  # Random target value
#linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
#linear_time2 = timeit.timeit(lambda: linear_search(sorted_list, target), number=200)
#linear_time3 = timeit.timeit(lambda: linear_search(sorted_list, target), number=500)
#linear_time4 = timeit.timeit(lambda: linear_search(sorted_list, target), number=1000)
#linear_time5 = timeit.timeit(lambda: linear_search(sorted_list, target), number=2000)
#linear_time6 = timeit.timeit(lambda: linear_search(sorted_list, target), number=5000)
#binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)
##binary_time2 = timeit.timeit(lambda: binary_search(sorted_list, target), number=200)
#binary_time3 = timeit.timeit(lambda: binary_search(sorted_list, target), number=500)
#binary_time4 = timeit.timeit(lambda: binary_search(sorted_list, target), number=1000)
#binary_time5 = timeit.timeit(lambda: binary_search(sorted_list, target), number=2000)
#binary_time6 = timeit.timeit(lambda: binary_search(sorted_list, target), number=5000)

#print(f"Linear search execution time for 100: {linear_time:.6f} seconds")
#print(f"Linear search execution time for 200: {linear_time2:.6f} seconds")
#print(f"Linear search execution time for 500: {linear_time3:.6f} seconds")
#print(f"Linear search execution time for 1000: {linear_time4:.6f} seconds")
#print(f"Linear search execution time for 2000: {linear_time5:.6f} seconds")
#print(f"Linear search execution time for 5000: {linear_time6:.6f} seconds")
#print(f"Binary search execution time for 100: {binary_time:.6f} seconds")
#print(f"Binary search execution time for 200: {binary_time2:.6f} seconds")
#print(f"Binary search execution time for 500: {binary_time3:.6f} seconds")
#print(f"Binary search execution time for 1000: {binary_time4:.6f} seconds")
#print(f"Binary search execution time for 2000: {binary_time5:.6f} seconds")
#print(f"Binary search execution time for 5000: {binary_time6:.6f} seconds")

# As we can see, for sorted data, binary search is orders of magnitude faster than
# linear search.


# SORTING ALGORITHMS
# Another major category of algorithm is the sorting algorithm. Sorting algorithms 
# are used to sort collections of elements into sorted order (such as numerical order for lists of numbers).


# BUBBLE SORT
def bubble_sort(arr):
    """
    Bubble Sort: A simple sorting algorithm that repeatedly steps through the list,
    compares adjacent elements, and swaps them if they are in the wrong order.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):

            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break

    return arr

# Example usage:
unsorted_list = [64, 25, 12, 22, 11]
sorted_list = bubble_sort(unsorted_list)
print("Sorted array:", sorted_list)



# INSERTION SORT
def insertion_sort(arr):
    """
    Insertion Sort: A simple sorting algorithm that builds the final sorted
    array one item at a time. It takes each element from the input list and
    inserts it into its correct position in the sorted part of the array.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr

# Example usage:
unsorted_list = [64, 1, 12, 22, 11]
sorted_list = insertion_sort(unsorted_list)
print("Sorted array:", sorted_list)

# Comparing bubble sort and insertion sort
# Generate a random unsorted list of 1000 integers
unsorted_list = [random.randint(1, 1000) for _ in range(10000)]

# Measure and compare the runtimes of Bubble Sort and Insertion Sort
#bubble_sort_time = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=1)
#bubble_sort_time2 = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=2)
#bubble_sort_time3 = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=5)
#bubble_sort_time4 = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=10)
#insertion_sort_time = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=1)
#insertion_sort_time2 = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=2)
#insertion_sort_time3 = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=5)
#insertion_sort_time4 = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=10)

#print(f"Bubble Sort Execution Time for 1: {bubble_sort_time:.6f} seconds")
#print(f"Bubble Sort Execution Time for 2: {bubble_sort_time2:.6f} seconds")
#print(f"Bubble Sort Execution Time for 5: {bubble_sort_time3:.6f} seconds")
#print(f"Bubble Sort Execution Time for 10: {bubble_sort_time4:.6f} seconds")
#print(f"Insertion Sort Execution Time for 1: {insertion_sort_time:.6f} seconds")
#print(f"Insertion Sort Execution Time for 2: {insertion_sort_time2:.6f} seconds")
#print(f"Insertion Sort Execution Time for 5: {insertion_sort_time3:.6f} seconds")
#print(f"Insertion Sort Execution Time for 10: {insertion_sort_time4:.6f} seconds")
###
# Both bubble sort and insertion sort are quite inefficient, since their runtime scales
# exponentially with the number of elements. However, they are useful for demonstrating
# the principles of sorting algorithms. 

# Challenge solution 1
def binary_search_insertion(array, target):
    array = insertion_sort(array)
    result = binary_search(array, target)
    return result

# Challenge solution 2
def linear_search_bubble(array, target):
    array = bubble_sort(array)
    result = linear_search(array, target)
    return result


# Challenge solution 3
def linear_search_insertion(array, target):
    array = insertion_sort(array)
    result = linear_search(array, target)
    return result


# Challenge solution 4
def binary_search_bubble(array, target):
    array = bubble_sort(array)
    result = binary_search(array, target)
    return result

unsorted_list = [random.randint(1, 1000) for n in range(10000)]
target = random.randint(1, 1000)

binary_insertion1 = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=1)
binary_insertion2 = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=10)
binary_insertion3 = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=100)
binary_insertion4 = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=200)

binary_bubble1 = timeit.timeit(lambda: binary_search_bubble(unsorted_list, target), number=1)
binary_bubble2 = timeit.timeit(lambda: binary_search_bubble(unsorted_list, target), number=10)
binary_bubble3 = timeit.timeit(lambda: binary_search_bubble(unsorted_list, target), number=10)
binary_bubble4 = timeit.timeit(lambda: binary_search_bubble(unsorted_list, target), number=100)

linear_insertion1 = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=1)
linear_insertion2 = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=10)
linear_insertion3 = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=10)
linear_insertion4 = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=100)

linear_bubble1 = timeit.timeit(lambda: linear_search_bubble(unsorted_list, target), number=1)
linear_bubble2 = timeit.timeit(lambda: linear_search_bubble(unsorted_list, target), number=10)
linear_bubble3 = timeit.timeit(lambda: linear_search_bubble(unsorted_list, target), number=10)
linear_bubble4 = timeit.timeit(lambda: linear_search_bubble(unsorted_list, target), number=100)


print(f"Binary Search (With Insertion) Execution Time: {binary_insertion1:.6f} seconds")
print(f"Binary Search (With Insertion) Execution Time: {binary_insertion2:.6f} seconds")
print(f"Binary Search (With Insertion) Execution Time: {binary_insertion3:.6f} seconds")
print(f"Binary Search (With Insertion) Execution Time: {binary_insertion4:.6f} seconds")

print(f"Binary Search (With Bubble) Execution Time: {binary_bubble1:.6f} seconds")
print(f"Binary Search (With Bubble) Execution Time: {binary_bubble2:.6f} seconds")
print(f"Binary Search (With Bubble) Execution Time: {binary_bubble3:.6f} seconds")
print(f"Binary Search (With Bubble) Execution Time: {binary_bubble4:.6f} seconds")

print(f"Linear Search (With Insertion) Execution Time: {linear_insertion1:.6f} seconds")
print(f"Linear Search (With Insertion) Execution Time: {linear_insertion2:.6f} seconds")
print(f"Linear Search (With Insertion) Execution Time: {linear_insertion3:.6f} seconds")
print(f"Linear Search (With Insertion) Execution Time: {linear_insertion4:.6f} seconds")

print(f"Linear Search (With Bubble) Execution Time: {linear_bubble1:.6f} seconds")
print(f"Linear Search (With Bubble) Execution Time: {linear_bubble2:.6f} seconds")
print(f"Linear Search (With Bubble) Execution Time: {linear_bubble3:.6f} seconds")
print(f"Linear Search (With Bubble) Execution Time: {linear_bubble4:.6f} seconds")

# One takeaway here is that the most efficient
# algorithm on paper isn't always the most 
# efficient in practice. If binary search requires
# sorted data, and we only have unsorted data,
# then we'll need to factor in the efficiency
# of the sorting algorithm as well when choosing
# a searching algorithm. In this case, linear search
# might win out simply because you don't need to 
# sort the list before searching.