import random
import timeit


# RECURSION
# At its core, recursion involves solving a problem 
# by breaking it down into smaller, more manageable instances of the same problem. 

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case



def sum_of_natural_numbers_iter(n):
    result = 1
    for i in range(1, n + 1):
        result += i
    return result

# Example usage:
result = sum_of_natural_numbers_iter(5)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 5 natural numbers is {result}")

# Compare times
recursion_time_basic = timeit.timeit(lambda: sum_of_natural_numbers(10))
iterative_time_basic = timeit.timeit(lambda: sum_of_natural_numbers_iter(10))
print(f"Time to complete basic recursive equation is {recursion_time_basic}")
print(f"Time to complete basic iterative equation is {iterative_time_basic}")

# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

def fibonacci_iter(n):
    if n <= 0:
        return 0
    if n == 1:
        return 1
    
    a, b = 0, 1  

    for i in range(2, n + 1):
        a, b = b, a + b

    return b
    
# Example usage:
result = fibonacci_iter(7)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The 7th Fibonacci number is {result}")
# Compare times
recursion_time_fib = timeit.timeit(lambda: fibonacci(10))
iterative_time_fib = timeit.timeit(lambda: fibonacci_iter(10))
print(f"Time to complete the fibonacci recursive equation is {recursion_time_fib}")
print(f"Time to complete the fibonacci iterative equation is {iterative_time_fib}")



# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

def factorial_iter(n):
    result = 1 
    for i in range(1, n + 1):
        result *= i
    return result

recursion_time_fac = timeit.timeit(lambda: fibonacci(10))
iterative_time_fac = timeit.timeit(lambda: fibonacci_iter(10))
print(f"Time to complete the factorial recursive equation is {recursion_time_fac}")
print(f"Time to complete the factorial iterative equation is {iterative_time_fac}")

# Example usage:
num = 5
result = factorial_iter(num)
print(f"The factorial of {num} is {result}")