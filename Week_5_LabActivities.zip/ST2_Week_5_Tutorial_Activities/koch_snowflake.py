from tkinter import * # Import tkinter
class KochSnowflake:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Sierpinski Triangle") # Set a title
        self.width = 300
        self.height = 300
        self.canvas = Canvas(window,
            width = self.width, height = self.height)
        self.canvas.pack()

        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()

        Label(frame1, 
            text = "Enter an order: ").pack(side = LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable = self.order,justify = RIGHT).pack(side = LEFT)
        Button(frame1, text = "Display Sierpinski Triangle",
        command = self.display).pack(side = LEFT)
        window.mainloop() # Create an event loop

    def display(self):
        self.canvas.delete("line")
        p1 = [self.width / 2, 10]
        p2 = [10, self.height - 10]
        p3 = [self.width - 10, self.height - 10]
        order = int(self.order.get())
        self.koch(order, p1, p2)
        self.koch(order, p2, p3)
        self.koch(order, p3, p1)

    def koch(self, order, p1, p2):
        if order == 0:
            self.drawLine(p1, p2)
        else:
            x1, y1 = p1
            x2, y2 = p2

            dx = (x2 - x1) / 3
            dy = (y2 - y1) / 3

            pA = [x1, y1]
            pB = [x1 + dx, y1 + dy]
            pD = [x1 + 2 * dx, y1 + 2 * dy]
            pE = [x2, y2]

            xC = pB[0] + dx * 0.5 - dy * 0.866
            yC = pB[1] + dx * 0.866 + dy * 0.5
            pC = [xC, yC]

            self.koch(order - 1, pA, pB)
            self.koch(order - 1, pB, pC)
            self.koch(order - 1, pC, pD)
            self.koch(order - 1, pD, pE)

    def drawLine(self, p1, p2):
        self.canvas.create_line(
        p1[0], p1[1], p2[0], p2[1], tags="line")       
    # Return the midpoint between two points
    def midpoint(self, p1, p2):
        p = 2 * [0]
        p[0] = (p1[0] + p2[0]) / 2
        p[1] = (p1[1] + p2[1]) / 2
        return p
KochSnowflake() # Create GUI